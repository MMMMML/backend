import Cookies from 'js-cookie'
const TokenKey = 'sessionId'

export function getSessionId () {
  // todo
  return Cookies.get(TokenKey)
  // return '29410a551db64fe78c69bb2c9ca6ef34'
}

export function getWxFrom () {
  // todo
  return 1
}
