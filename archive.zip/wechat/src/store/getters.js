export const commonPeople = state => state.commonPeople
