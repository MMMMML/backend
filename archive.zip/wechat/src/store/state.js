const state = {
  commonPeople: {
    realName: '',
    idType: '',
    idNumber: '',
    mobile: '',
    blood: '',
    emergencyContact: '',
    emergencyPhone: '',
    familyHistory: '',
    otherInfo: ''
  }
}

export default state
