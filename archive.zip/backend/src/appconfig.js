export default {
    serverRootUrl:'http://172.28.2.59:8101/backend/'
  }