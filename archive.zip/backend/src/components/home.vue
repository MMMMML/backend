<template>
  <div class="homepage">
    <h1>欢迎使用空降联盟服务平台</h1>
  </div>
</template>



<style>
.homepage{
  margin: 20% auto;
  text-align: center;
}
.homepage h1{
  font-size: 30px
}
</style>

<script>
  export default {
    
  };
</script>